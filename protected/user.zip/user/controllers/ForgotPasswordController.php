<?php

class ForgotPasswordController extends Controller {

        public function actionIndex() {
                $this->render('index');
        }

}
