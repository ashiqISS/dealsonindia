<section class="banner">
        <div class="container">
                <div class="row">
                        <div class="col-xs-12">
                                <img src="<?= Yii::app()->baseUrl ?>/images/c1.jpg">
                        </div>
                </div>
        </div>
</section>



<section class="deals-products">
        <div class="container">
                <div class="row">

                        <div class="rows">
                                <div class="col-md-12">
                                        <h6>Daily Deals</h6>
                                        <div class="listed">
                                                <!--                        <form>
                                                                            <div class="form-group">
                                                                                <label for="email">Sort By</label>
                                                                                <select class="chris-select" name="carlist" form="carform">
                                                                                    <option value="volvo">Default</option>
                                                                                    <option value="saab">Saab</option>
                                                                                    <option value="opel">Opel</option>
                                                                                    <option value="audi">Audi</option>
                                                                                </select>
                                                                            </div>
                                                                        </form>-->

                                                <form class="form-inline" role="form">
                                                        <label class="sortby">Sort By</label>
                                                        <div class="form-group">

                                                                <select class="chris-select animated fadeInUp" name="carlist" form="carform">
                                                                        <option value="volvo">Default</option>
                                                                        <option value="saab">Saab</option>
                                                                        <option value="opel">Opel</option>
                                                                        <option value="audi">Audi</option>
                                                                </select>
                                                        </div>


                                                </form>





                                        </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d5.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d1.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d4.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d2.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                        </div>
                        <div class="rows">

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d3.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>


                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <img class="img-responsive adz" src="<?= Yii::app()->baseUrl ?>/images/sd.jpg">


                                </div>
                                <div class="visible-sm visible-xs clearfix"></div>

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d5.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d1.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                        </div>


                        <div class="rows">

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d4.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d5.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <img class="img-responsive adz" src="<?= Yii::app()->baseUrl ?>/images/sd.jpg">


                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d3.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>


                                <div class="visible-sm visible-xs clearfix"></div>
                        </div>

                        <div class="rows">

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d5.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d1.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d4.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d2.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                        </div>


                        <div class="rows">

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d4.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d5.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <img class="img-responsive adz" src="<?= Yii::app()->baseUrl ?>/images/sd.jpg">


                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d3.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>


                                <div class="visible-sm visible-xs clearfix"></div>
                        </div>

                        <div class="rows">

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d5.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d1.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d4.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d2.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                        </div>


                        <div class="rows">

                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d4.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>



                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d5.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>

                                <div class="visible-sm visible-xs clearfix"></div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <img class="img-responsive adz" src="<?= Yii::app()->baseUrl ?>/images/sd.jpg">


                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-6 mob deals-effects">
                                        <div class="deals-effect">
                                                <img class="zoom" src="<?= Yii::app()->baseUrl ?>/images/d3.jpg">
                                                <div class="overlay"></div>
                                                <div class="buy">
                                                        <a class="buybtn" href="#">Buy Now</a>
                                                </div>
                                        </div>



                                        <h2>Big Rock CouponsFlat 35% OFF
                                                on Shared Hosting</h2>
                                        <div class="star">
                                                <ul>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                        <li><i class="fa stars fa-star-o"></i></li>
                                                </ul>
                                        </div>


                                        <div class="blocked">
                                                <div class="social">
                                                        <ul>
                                                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                                        </ul>
                                                </div>

                                                <div class="price">
                                                        <h3>249.00</h3>
                                                </div>
                                        </div>
                                </div>


                                <div class="visible-sm visible-xs clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                        <button class="ripple">Load More</button>
                </div>
        </div>


</section>

<script>
        (function (window, $) {
                $(function () {
                        $('.ripple').on('click', function (event) {
                                event.preventDefault();
                                var $div = $('<div/>'),
                                        btnOffset = $(this).offset(),
                                        xPos = event.pageX - btnOffset.left,
                                        yPos = event.pageY - btnOffset.top;
                                $div.addClass('ripple-effect');
                                var $ripple = $(".ripple-effect");

                                $ripple.css("height", $(this).height());
                                $ripple.css("width", $(this).height());
                                $div
                                        .css({
                                                top: yPos - ($ripple.height() / 2),
                                                left: xPos - ($ripple.width() / 2),
                                                background: $(this).data("ripple-color")
                                        })
                                        .appendTo($(this));

                                window.setTimeout(function () {
                                        $div.remove();
                                }, 2000);
                        });

                });

        })(window, jQuery);
</script>