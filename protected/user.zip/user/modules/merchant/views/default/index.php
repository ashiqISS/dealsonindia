<?php

echo 'Welcome  '.Yii::app()->user->getState('user_mail');