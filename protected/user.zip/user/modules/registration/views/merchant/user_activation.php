<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

echo "Hi $model->fullname";?>
<br><br> You will be redirected to our payment gateway to complete the registration by paying the membership fee.
Click below to continue